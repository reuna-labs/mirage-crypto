from pathlib import Path
import hashlib,json,os,subprocess,tarfile
root=Path('/tmp')
paths=set(root.glob('*.log'))
for pattern in ['octez-*-rule.sexp','octez-*-rules.sexp','octez-*.py','octez-*cram.out']:
 paths.update(root.glob(pattern))
for directory in [root/'octez-full/test_results',root/'octez-proof-backend-comparison']:
 if directory.exists():
  paths.update(p for p in directory.rglob('*') if p.is_file() and p.suffix in ['.log','.output','.diff','.xml'])
for directory in root.iterdir():
 if directory.is_dir() and directory.name.startswith(('mc-','edb32-','web3-assurance','octez-solo5-')):
  for base,dirs,files in os.walk(directory):
   dirs[:]=[d for d in dirs if d not in ['.git','vendor','vendors','_opam','node_modules']]
   for name in files:
    p=Path(base)/name
    if name.endswith('.log') or name in ['signer_solo5.exe','main.spt','main.virtio']:
     if p.is_file(): paths.add(p)
metadata={
 'ocaml':subprocess.check_output(['opam','exec','--switch=octez-5.3','--','ocamlc','-version'],text=True).strip(),
 'opam_packages':subprocess.check_output(['opam','list','--switch=octez-5.3','--installed','--columns=name,version','--short'],text=True),
 'files':{str(p.relative_to(root)): {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)}}
(root/'octez-evidence-index.json').write_text(json.dumps(metadata,indent=2)+'\n')
paths.add(root/'octez-evidence-index.json')
with tarfile.open('/tmp/octez-validation-evidence.tar.gz','w:gz') as tar:
 for p in sorted(paths):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
print(len(paths),'files; archive bytes:',(root/'octez-validation-evidence.tar.gz').stat().st_size)
