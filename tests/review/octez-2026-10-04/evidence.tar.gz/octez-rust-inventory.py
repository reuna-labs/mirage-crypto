import json,hashlib,re,tomllib,urllib.request,tarfile,io
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path('/tmp/octez-full')
selected={'bellman','bls12_381','jubjub','zcash_primitives','zcash_proofs','orchard','pasta_curves','ff','group','subtle','blake2b_simd','blake2s_simd','zcash_note_encryption','libcrux-ml-dsa','libcrux-sha3','libcrux-platform','libcrux-intrinsics','libcrux-traits','hax-lib','ocaml','ocaml-sys','ocaml-boxroot-sys','zeroize'}
report={}
jobs={}
for component in ['rustzcash_deps','rust_libcrux']:
 lock=root/'src'/component/'Cargo.lock'
 packages=tomllib.loads(lock.read_text())['package']
 crates=[{k:p[k] for k in ['name','version','source','checksum'] if k in p} for p in packages if p['name'] in selected]
 for p in crates:
  if 'checksum' in p: jobs[(p['name'],p['version'])]=p
 source=root/'src'/component/'src'/('rustzcash.rs' if component=='rustzcash_deps' else 'lib.rs')
 exports=re.findall(r'pub (?:extern "C" )?fn (\w+)\(',source.read_text())
 report[component]={'lock_sha256':hashlib.sha256(lock.read_bytes()).hexdigest(),'wrapper_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'exports':exports,'selected_crates':crates}
def fetch(item):
 (name,version),p=item
 url=f'https://static.crates.io/crates/{name}/{name}-{version}.crate'
 data=urllib.request.urlopen(url,timeout=45).read()
 assert hashlib.sha256(data).hexdigest()==p['checksum'],name
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
  meta=tomllib.loads(archive.extractfile(f'{name}-{version}/Cargo.toml').read().decode())['package']
  license_files=[t.name for t in archive.getmembers() if re.search(r'/(LICENSE|COPYING|NOTICE)([^/]*$)',t.name)]
  result={'archive':url,'license':meta.get('license'),'repository':meta.get('repository'),'license_files':{n:hashlib.sha256(archive.extractfile(n).read()).hexdigest() for n in license_files if archive.getmember(n).isfile()}}
  if name=='zcash_proofs':
   text=archive.extractfile(f'{name}-{version}/src/lib.rs').read().decode()
   Path('/tmp/zcash_proofs-pinned-lib.rs').write_text(text)
 return (name,version),result
with ThreadPoolExecutor(max_workers=4) as pool:
 sources=dict(pool.map(fetch,jobs.items()))
for comp in report.values():
 for p in comp['selected_crates']:
  p.update(sources.get((p['name'],p['version']),{}))
bindings=(root/'src/lib_sapling/bindings/rustzcash_ctypes_bindings.ml').read_text()
report['rustzcash_deps']['octez_bound_exports']=sorted(set(re.findall(r'"(librustzcash_\w+)"',bindings)))
Path('/tmp/octez-rust-inventory.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'Inventoried {len(sources)} checksum-verified crate archives')
