((deps ((File (In_source_tree src/bin_snoop/snoop-command.t))))
 (targets
  ((files (_build/default/src/bin_snoop/snoop-command.t)) (directories ())))
 (context default)
 (action
  (copy
   src/bin_snoop/snoop-command.t
   _build/default/src/bin_snoop/snoop-command.t)))
