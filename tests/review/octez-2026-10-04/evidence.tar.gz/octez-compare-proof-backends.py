import json, os, re, subprocess
from pathlib import Path
root=Path('/tmp/octez-full/_build/default')
old=Path('/tmp/octez-bls-original/src/lib_bls12_381')
out=Path('/tmp/octez-proof-backend-comparison');out.mkdir(exist_ok=True)

def parse(text):
    toks=iter(re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',text))
    def item(tok):
        if tok=='(':
            result=[]
            for token in toks:
                if token==')':return result
                result.append(item(token))
            raise ValueError('unterminated expression')
        return json.loads(tok) if tok.startswith('"') else tok
    return [item(tok) for tok in toks]

def find_run(tree):
    if isinstance(tree,list):
        if len(tree)>1 and tree[0]=='run' and isinstance(tree[1],str) and tree[1].endswith('ocamlopt.opt'):
            return tree[1:]
        for child in tree:
            got=find_run(child)
            if got:return got
    return None

for name,sub in [('plonk','src/lib_plonk/test'),('aplonk','src/lib_aplonk/test'),('plompiler','src/lib_plonk/test_plompiler')]:
    args=find_run(parse(Path('/tmp/octez-'+name+'-link-rule.sexp').read_text()))
    assert args and '-o' in args
    args[args.index('-o')+1]=str(out/(name+'-original'))
    replacements=0
    for i in range(len(args)-1):
        if args[i]=='-I' and args[i+1]=='src/lib_bls12_381':
            args[i+1]=str(old);replacements+=1
    assert replacements>0
    args += ['-ccopt','-Wl,-t']
    with (out/(name+'-link.log')).open('w') as log:
        subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    linked=(out/(name+'-link.log')).read_text()
    for archive in ['libblst.a','libbls12_381_stubs.a']:
        assert str(old/archive) in linked, ('original archive not selected',archive)
        assert str(root/'src/lib_bls12_381'/archive) not in linked
    env=os.environ.copy();env['RANDOM_SEED']='42'
    for variant,exe in [('original',out/(name+'-original')),('candidate',root/sub/'main.exe')]:
        work=out/(name+'-'+variant+'-run');work.mkdir(exist_ok=True)
        with (work/'run.log').open('w') as log:
            subprocess.run([str(exe),'-q'],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    original=(out/(name+'-original-run')/'test.output').read_bytes()
    candidate=(out/(name+'-candidate-run')/'test.output').read_bytes()
    assert original==candidate, name+' original/candidate proof output differs'
    print(name+': original/candidate outputs match ('+str(len(original.splitlines()))+' lines)',flush=True)
