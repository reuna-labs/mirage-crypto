import os
import shutil
import signal
import subprocess
import sys
import time

log_path, *command = sys.argv[1:]
env = os.environ.copy()
env['PATH'] = '/tmp/octez-lint-bin:/home/opam/.cargo/bin:' + env['PATH']
env['CARGO_BUILD_JOBS'] = '2'
env['CARGO_TARGET_RISCV64GC_UNKNOWN_LINUX_MUSL_LINKER'] = 'riscv64-linux-gnu-gcc'
env['DUNE_ARGS'] = '-j 4'
with open(log_path, 'w') as log:
    process = subprocess.Popen(command, cwd='/tmp/octez-full', env=env,
                               stdout=log, stderr=subprocess.STDOUT,
                               start_new_session=True)
    while process.poll() is None:
        if shutil.disk_usage('/tmp').free < 4 * 1024**3:
            log.write('\nVALIDATION STOPPED: less than 4 GiB disk headroom\n')
            log.flush()
            os.killpg(process.pid, signal.SIGINT)
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait()
            sys.exit(75)
        time.sleep(5)
    sys.exit(process.returncode)
